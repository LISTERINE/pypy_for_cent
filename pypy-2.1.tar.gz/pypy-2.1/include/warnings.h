#ifndef Py_WARNINGS_H
#define Py_WARNINGS_H
#ifdef __cplusplus
extern "C" {
#endif

#define PyErr_WarnPy3k(msg, stacklevel) 0

#ifdef __cplusplus
}
#endif
#endif /* !Py_WARNINGS_H */
